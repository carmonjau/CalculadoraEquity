import java.util.ArrayList;

public class Mano {
	
	//Lista de TODAS las cartas que forman la mano
	private ArrayList<Carta> cartas;
	//Mejores 5 cartas para mostrar cuando hay mas de 5
	private ArrayList<Carta> cartasBoF;
	
	//Lista de cartas que son As
	private ArrayList<Carta> cartasA;
	
	//Booleanos de a y palo
	boolean ac;
	boolean ad;
	boolean ah;
	boolean as;
	
	//Listas de las cartas separadas por color
	private ArrayList<Carta> cartasColorC;
	private ArrayList<Carta> cartasColorD;
	private ArrayList<Carta> cartasColorH;
	private ArrayList<Carta> cartasColorS;
	
	//Lista de las cartas que forman las parejas
	private ArrayList<Carta> cartasParejas;

	
	//Lita de las cartas de la escalera
	private ArrayList<Carta> cartasEscalera;
	private ArrayList<Carta> cartasEscaleraHueco;
	
	//Combinacion mas alta que tiene la mano
	private Combinacion combinacion; 
	
	//Combinacion mas alta de repeticion de cartas
	private Combinacion comboParejas;
	
	//Lista de draws
	private ArrayList<Combinacion> draws;
	
	//Lo cambio a una variable palo para proyecto de color y a una variable boolean para escalera
	private char proyectoColor;
	private char color;
	private boolean proyectoEscalera;
	private boolean escalera;
	private boolean hueco;
	private int contadorEscalera;
	private int contadorEscaleraHueco;
	
	//Array de 4 posiciones, 1 con cada contador de los palos
	//Posicion 0 = c Posicion 1 = d Posicion 2 = h Posicion 3 = s
	private Integer[] contadorPalos; 
	
	public Mano() {
		cartas = new ArrayList<>();
		cartasBoF = new ArrayList<>();
		cartasColorC = new ArrayList<>();
		cartasColorD = new ArrayList<>();
		cartasColorH = new ArrayList<>();
		cartasColorS = new ArrayList<>();
		cartasParejas = new ArrayList<>();
		cartasEscalera = new ArrayList<>();
		cartasEscaleraHueco = new ArrayList<>();
		cartasA = new ArrayList<>();
		ac = false;
		ad = false;
		ah = false;
		as = false;
		draws = new ArrayList<>();
		setProyectoColor('z');
		setColor('z');
		proyectoEscalera = false;
		setEscalera(false);
		hueco = false;
		combinacion = Combinacion.CARTA_ALTA;
		comboParejas = Combinacion.CARTA_ALTA;
		contadorEscalera = 1;
		contadorEscaleraHueco = 1;
		contadorPalos = new Integer[] {0,0,0,0};
	}
	
	public void anadirCarta(ArrayList<Carta> cartas, Carta c){
		if (cartas.isEmpty()){
			cartas.add(c);
		}
		else{
			int index = buscaPosicion(cartas, c.getHashCode(), 0, cartas.size() - 1);
			cartas.add(index, c);
		}
	}
	
	public int buscaPosicion(ArrayList<Carta> cartas, int hc, int ini, int fin){
		if (fin < ini) {
	        return ini;
	    }
		int medio = (ini + fin) / 2;
	    if (hc == cartas.get(medio).getHashCode()) {
	        return medio;
	    } else if (hc < cartas.get(medio).getHashCode()) {
	        return buscaPosicion(cartas, hc, ini, medio - 1);
	    } else {
	        return buscaPosicion(cartas, hc, medio + 1, fin);
	    }
	}
	
	public Combinacion getCombinacion() {
		return combinacion;
	}
	
	private boolean setCombinacion(Combinacion comboNuevo) {
		if (combinacion == null) {
			combinacion = comboNuevo;
			return true;
		}
		else {
			if (combinacion.compare(combinacion, comboNuevo) == -1) {
				combinacion = comboNuevo;
				return true;
			}
		}
		return false;
	}
	
	private boolean setComboParejas(Combinacion comboNuevo) {
		if (comboParejas == null) {
			comboParejas = comboNuevo;
			return true;
		}
		else {
			if (comboParejas.compare(comboParejas, comboNuevo) == -1) {
				comboParejas = comboNuevo;
				return true;
			}
		}
		return false;
	}
	
	/**
	 * 
	 * @param carta: carta que se anade a la baraja
	 * Al anadir se comprueba si hay proyecto de color/color y se modifican
	 * los atributos correspondientes de la Mano
	 */
	public void addCarta(Carta carta) {
		
		char palo = carta.getPalo();
		//Comprobamos que sea un as
		//Si lo es anadimos booleano a true del palo que es y metemos la carta en el array de A
		if (carta.getValorP1() == 14){
			switch(carta.getPalo()){
			case 'c': ac = true; break;
			case 'd': ad = true; break;
			case 'h': ah = true; break;
			case 's': as = true; break;
			}
			anadirCarta(cartasA, carta);
			Carta c = new Carta();
			c.setPalo(carta.getPalo());
			c.setValor('1');
			c.setHashCode();
			anadirCarta(cartas, c);
		}
		// Tratamos color
		comprobarColor(palo, carta);
		// Anadimos la combinacion si tenemos color o proyecto
		// Anadimos la carta
		anadirCarta(cartas, carta);
	}
	
	// Comprueba el color de la carta
	// Aumenta contadores y actualiza las variables de proyecto color y color
	// Agrupa las cartas en listas por color que se comprobaran en caso de empate
	private void comprobarColor(char palo, Carta carta){
		switch(palo){
		case 'c': 
		this.contadorPalos[0]++;
		anadirCarta(cartasColorC, carta);
		switch(this.contadorPalos[0]) {
			case 4:
				setProyectoColor('c');
				break;
			case 5: 
				setProyectoColor('z');
				setColor('c');
				break;
			default: break;
		}
		break;
		case 'd': 
		this.contadorPalos[1]++;
		anadirCarta(cartasColorD, carta);
		switch(this.contadorPalos[1]) {
			case 4: 
				setProyectoColor('d');
				break;
			case 5: 
				setProyectoColor('z');
				setColor('d');
				break;
			default: break;
		} 
		break;
		case 'h': 
		this.contadorPalos[2]++;
		anadirCarta(cartasColorH, carta);
		switch(this.contadorPalos[2]) {
			case 4: 
				setProyectoColor('h');
				break;
			case 5: 
				setProyectoColor('z');
				setColor('h');
				break;
			default: break;
		}
		break;
		case 's': 
		this.contadorPalos[3]++;
		anadirCarta(cartasColorS, carta);
		switch(this.contadorPalos[3]) {
		case 4:
			setProyectoColor('s');
			break;
		case 5: 
			setProyectoColor('z');
			setColor('s');
			break;
		default: break;
		}
		break;
		}
	}

	//Metodo que actualiza el atributo combinacion con el combo que tiene la mano
	public void combinacionEnMano() {
		//Comprobamos escalera
		comprobarEscalera(cartas);
		//Comprobamos la repeticion de cartas
		comprobarPares(cartas);
		//A�adimos los draws y combinaciones de color
		anadirColorYDraw();
		//A�adimos los draws y combinaciones de escalera
		anadirEscaleraYDraw();
		//Comprobamos cual de las dos combinaciones hasta ahora es mejor:
		//Si la general en la que ahora mismo solo hay color, escalera o escalera real
		//O la de parejas
		setCombinacion(comboParejas);
		// Borro los proyectos que no me interesa
		if ((combinacion.equals(Combinacion.FULL) || combinacion.equals(Combinacion.POKER)) && !(proyectoEscalera && proyectoColor != 'z') ){
			draws.clear();
		}
		// Meto las mejores 5 cartas para mostrar
		if (cartas.size() >= 5){
			seleccionarBoF();
		}
	}
	
	private void seleccionarBoF(){
		switch(combinacion){
		case ESCALERA_REAL:
			cartasBoF = cartasEscalera; break;
		case POKER: 
			for(int i = 0; i < cartasParejas.size(); i++){
				anadirCarta(cartasBoF, cartasParejas.get(i));
				cartas.remove(cartasParejas.get(i));
			}
			cartasBoF.add(4, cartas.get((cartas.size() - 1)));
			for(int i = 0; i < cartasParejas.size(); i++){
				anadirCarta(cartas, cartasParejas.get(i));
			}
			break;
		case FULL: 
			cartasBoF = cartasParejas; break;
		case COLOR: 
			switch(color){
			case 'c': 
				while (cartasColorC.size() > 5) {
					cartasColorC.remove(0);
				}
				cartasBoF = cartasColorC; break;
			case 'd': while (cartasColorD.size() > 5) {
				cartasColorD.remove(0);
			}
			cartasBoF = cartasColorD; break;
			
			case 'h': while (cartasColorH.size() > 5) {
				cartasColorH.remove(0);
			}
				cartasBoF = cartasColorH; break;
			case 's': while (cartasColorS.size() > 5) {
				cartasColorS.remove(0);
			}
				cartasBoF = cartasColorS; break;
			default: break;
			}
			break;
		case ESCALERA: 
			cartasBoF = cartasEscalera; break;
		case TRIO: 
			for(int i = 0; i < cartasParejas.size(); i++){
				anadirCarta(cartasBoF, cartasParejas.get(i));
				cartas.remove(cartasParejas.get(i));
			}
			cartasBoF.add(3, cartas.get((cartas.size() - 1)));
			cartasBoF.add(4, cartas.get((cartas.size() - 2)));
			for(int i = 0; i < cartasParejas.size(); i++){
				anadirCarta(cartas, cartasParejas.get(i));
			}
			break;
		case DOBLES_PAREJAS:
			for(int i = 0; i < cartasParejas.size(); i++){
				anadirCarta(cartasBoF, cartasParejas.get(i));
				cartas.remove(cartasParejas.get(i));
			}
			cartasBoF.add(4, cartas.get(cartas.size() - 1));
			for(int i = 0; i < cartasParejas.size(); i++){
				anadirCarta(cartas, cartasParejas.get(i));
			}
			break;
		case PAREJA:
			for(int i = 0; i < cartasParejas.size(); i++){
				anadirCarta(cartasBoF, cartasParejas.get(i));
				cartas.remove(cartasParejas.get(i));
			}
			cartasBoF.add(2, cartas.get(cartas.size() - 1));
			cartasBoF.add(3, cartas.get(cartas.size() - 2));
			cartasBoF.add(4, cartas.get(cartas.size() - 3));
			for(int i = 0; i < cartasParejas.size(); i++){
				anadirCarta(cartas, cartasParejas.get(i));
			}
			break;
		case CARTA_ALTA:
			for(int i = cartas.size()-1; i > cartas.size()-6; i--){
				anadirCarta(cartasBoF, cartas.get(i));
			}
			break;
		default: break;
		}
	}
	
	private void comprobarEscalera(ArrayList<Carta> cartas) {
		boolean parar = false;
		int i = cartas.size()-1;
		this.cartasEscalera.clear();
		anadirCarta(cartasEscalera, cartas.get(cartas.size()-1));
		while (!parar && i > 0){
			Carta c1 = cartas.get(i);
			Carta c2 = cartas.get(i-1);
			//Si se diferencian en 1
			if (c1.getValorP1() == c2.getValorP1()+1 && !escalera) {
				contadorEscalera++;
				// Si habia un hueco aumentamos y a�adimos la carta en el segundo array
				if (hueco){
					contadorEscaleraHueco++;
					anadirCarta(cartasEscaleraHueco, c2);
				}
				anadirCarta(cartasEscalera, c2);
				// Si el contador es 4 hay proyecto
				if (contadorEscalera == 4)
					proyectoEscalera = true;
				// Si es 5 y no hay hueco hay escalera
				if (contadorEscalera == 5 && !hueco) {
					parar = true;
					proyectoEscalera = false;
					setEscalera(true);
				}
				// Si el contador del segundo array es 5 hay escalera en el segundo
				// Se sustituyen
				if (contadorEscaleraHueco == 5){
					parar = true;
					proyectoEscalera = false;
					escalera = true;
					contadorEscalera = contadorEscaleraHueco;
					contadorEscaleraHueco = 1;
					cartasEscalera = new ArrayList<Carta>(cartasEscaleraHueco);
					cartasEscaleraHueco.clear();
				}
			}
			// Caso v1 > v2 en dos unidades
			else {
				if (c1.getValorP1() == c2.getValorP1()+2 && !escalera) {
					// Si no hay hueco, inicializo el segundo array apartir de este elemento
					if (!hueco) {
						hueco = true;
						contadorEscalera++;
						anadirCarta(cartasEscalera, c2);
						anadirCarta(cartasEscaleraHueco, c2);
						if (contadorEscalera == 4)
							proyectoEscalera = true;
						// Si llego a 5 y tengo hueco en esta comprobacion, es el proyecto mas alto que puedo alcanzar y no puede formarse escalera.
						if (contadorEscalera == 5) {
							parar = true;
							contadorEscalera = 4;
						}
					}
					else {
						// No va a haber escalera y este es el proyecto mas alto
						if (proyectoEscalera){
							parar = true;
						}
						// Si no hay proyecto se sustituyen arrays, podria haber escalera o proyecto
						else{
							contadorEscalera = contadorEscaleraHueco + 1;
							contadorEscaleraHueco = 1;
							cartasEscalera = new ArrayList<Carta>(cartasEscaleraHueco);
							cartasEscaleraHueco.clear();
							anadirCarta(cartasEscalera, c2);
							anadirCarta(cartasEscaleraHueco, c2);
						}
					}
				}
				else {
					if (c1.getValorP1() > c2.getValorP1()+2 && !escalera) {
						// No va a haber escalera y este es el proyecto mas alto
						if (proyectoEscalera){
							parar = true;
						}
						// Reinicio todo
						else{
							contadorEscalera = 1;
							contadorEscaleraHueco = 1;
							cartasEscalera.clear();
							cartasEscaleraHueco.clear();
							anadirCarta(cartasEscalera, c2);
							hueco = false;
						}
					}
				}
			}
			i--;
		}
		if (cartasA.size()>0){
			if ((proyectoEscalera || escalera) && !cartasEscalera.isEmpty()){
				if (cartasEscalera.get(0).getValorP1() == 1){
					if (color != 'z'){
						switch(color){
						case 'c':
							if (ac) {
								Carta det = cartasA.get(buscaPosicion(cartasA, 140, 0, cartasA.size()-1));
								anadirCarta(cartasEscalera, det);
							}
							break;
						case 'd':
							if (ad) {
								Carta det = cartasA.get(buscaPosicion(cartasA, 141, 0, cartasA.size()-1));
								anadirCarta(cartasEscalera, det);
							}
							break;
						case 'h':
							if (ah) {
								Carta det = cartasA.get(buscaPosicion(cartasA, 142, 0, cartasA.size()-1));
								anadirCarta(cartasEscalera, det);
							}
							break;
						case 's':
							if (as) {
								Carta det = cartasA.get(buscaPosicion(cartasA, 143, 0, cartasA.size()-1));
								anadirCarta(cartasEscalera, det);
							}
							break;
						default: break;
						}
						cartasEscalera.remove(0);
					}
					else{
						anadirCarta(cartasEscalera, cartasA.get(cartasA.size()-1));
						cartasEscalera.remove(0);
					}
				}
				
			}
			for (int j = 0; j<cartasA.size(); j++){
				cartas.remove(0);
			}
		}
	}

	private void comprobarPares(ArrayList<Carta> cartas) {
		int iguales = 1;
		
		
		for (int i = cartas.size() - 1; i > 0; i--) {
			if (cartas.get(i).getValorP1() == cartas.get(i-1).getValorP1()) {
				iguales++;
				anadirCarta(this.cartasParejas, cartas.get(i));
			}
			else {
				auxiliarComprobarPares(iguales, cartas.get(i));
				iguales = 1;
			}
		}
		auxiliarComprobarPares(iguales, cartas.get(0));
	}
	
	private void auxiliarComprobarPares(int iguales, Carta c){
		if (iguales > 1)
			anadirCarta(this.cartasParejas, c);
		
		if (iguales == 4) {
			if (comboParejas.equals(Combinacion.CARTA_ALTA))
			setComboParejas(Combinacion.POKER);
			else if (comboParejas.equals(Combinacion.PAREJA)){
				setComboParejas(Combinacion.POKER);
				cartasParejas.remove(4);
				cartasParejas.remove(4);
			}
			else if (comboParejas.equals(Combinacion.TRIO)){
				setComboParejas(Combinacion.POKER);
				cartasParejas.remove(4);
				cartasParejas.remove(4);
				cartasParejas.remove(4);
			}
			else if (comboParejas.equals(Combinacion.DOBLES_PAREJAS)){
				setComboParejas(Combinacion.POKER);
				cartasParejas.remove(4);
				cartasParejas.remove(4);
				cartasParejas.remove(4);
				cartasParejas.remove(4);
			}
			else if (comboParejas.equals(Combinacion.FULL)){
				setComboParejas(Combinacion.POKER);
				cartasParejas.remove(4);
				cartasParejas.remove(4);
				cartasParejas.remove(4);
				cartasParejas.remove(4);
				cartasParejas.remove(4);
			}
			else if (comboParejas.equals(Combinacion.POKER)){
				cartasParejas.remove(0);
				cartasParejas.remove(0);
				cartasParejas.remove(0);
				cartasParejas.remove(0);
			}	
		}
		else if (iguales == 3) {
			if (comboParejas.equals(Combinacion.CARTA_ALTA))
				setComboParejas(Combinacion.TRIO);
			else if (comboParejas.equals(Combinacion.PAREJA)){
				setComboParejas(Combinacion.FULL);
			}
			else if (comboParejas.equals(Combinacion.TRIO)){
				setComboParejas(Combinacion.FULL);
				cartasParejas.remove(0);
			}
			else if (comboParejas.equals(Combinacion.DOBLES_PAREJAS)){
				setComboParejas(Combinacion.FULL);
				cartasParejas.remove(3);
				cartasParejas.remove(3);
			}
			else{
				cartasParejas.remove(0);
				cartasParejas.remove(0);
				cartasParejas.remove(0);
			}
		}
		else if (iguales == 2) {
			if (comboParejas.equals(Combinacion.CARTA_ALTA))
				setComboParejas(Combinacion.PAREJA);
			else if (comboParejas.equals(Combinacion.PAREJA)){
				setComboParejas(Combinacion.DOBLES_PAREJAS);
			}
			else if (comboParejas.equals(Combinacion.TRIO)){
				setComboParejas(Combinacion.FULL);
			}
			else{
				cartasParejas.remove(0);
				cartasParejas.remove(0);
			}
		}
	}

	private void anadirColorYDraw(){
		if (proyectoColor != 'z'){
			draws.add(Combinacion.COLOR);
		}
		if (color != 'z'){
			setCombinacion(Combinacion.COLOR);
		}
	}
	
	private boolean comparaListasCartas(ArrayList<Carta> a, ArrayList<Carta> b){
		boolean iguales = true;
		if(a.size() != b.size())
			return false;
		else{
			int i = 0;
			while(iguales && i < a.size()){
				if (!a.get(i).equals(b.get(i)))
					iguales = false;
				i++;
			}
		}
		
		return iguales;
	}

	private void anadirEscaleraYDraw(){
		// Si hay proyecto de escalera lo anadimos a draw
		if (proyectoEscalera && color == 'z'){
			draws.add(Combinacion.ESCALERA);
		}
		// Si hay proyecto de escalera y de color anadimos draw de escalera real
		if(proyectoEscalera && proyectoColor != 'z'){
			switch(proyectoColor){
			case 'c':
				if (comparaListasCartas(cartasColorC, cartasEscalera)){
					draws.add(Combinacion.ESCALERA_REAL);
				}
				break;
			case 'd':
				if (comparaListasCartas(cartasColorD, cartasEscalera)){
					draws.add(Combinacion.ESCALERA_REAL);
				}
				break;
			case 'h':
				if (comparaListasCartas(cartasColorH, cartasEscalera)){
					draws.add(Combinacion.ESCALERA_REAL);
				}
				break;
			case 's':
				if (comparaListasCartas(cartasColorS, cartasEscalera)){
					draws.add(Combinacion.ESCALERA_REAL);
				}
				break;
			default: break;
			}
		}
		// Si tenemos color y escalera a�adimos escalera real
		if(color != 'z' && escalera){
			switch(color){
			case 'c':
				if (comparaListasCartas(cartasColorC, cartasEscalera)){
					setCombinacion(Combinacion.ESCALERA_REAL);
				}
				break;
			case 'd':
				if (comparaListasCartas(cartasColorD, cartasEscalera)){
					setCombinacion(Combinacion.ESCALERA_REAL);
				}
				break;
			case 'h':
				if (comparaListasCartas(cartasColorH, cartasEscalera)){
					setCombinacion(Combinacion.ESCALERA_REAL);
				}
				break;
			case 's':
				if (comparaListasCartas(cartasColorS, cartasEscalera)){
					setCombinacion(Combinacion.ESCALERA_REAL);
				}
				break;
			default: break;
			}
		}
		else{
			// Si tenemos escalera y no color a�adimos escalera
			if (escalera){
				setCombinacion(Combinacion.ESCALERA);
			}
		}
	}
	
	public String toString() {
		String s = "";
        for (int i = cartas.size() - 1; i >= 0; i--) {
			 s += cartas.get(i).toString();
		}
			
		return s;
	}
	
	public String toStringBestHand(){
		String s = "";
		
		switch(combinacion){
		case ESCALERA_REAL: s += "Straight flush (" + toStringEscalera() + ")"; break;
		case POKER: s += "Four of a (" + toStringParejas() + ")"; break;
		case FULL: s += "Full house (" + toStringParejas() + ")"; break;
		case COLOR: s += "Flush (" + toStringColor() + ")"; break;
		case ESCALERA: s += "Straight (" + toStringEscalera() + ")"; break;
		case TRIO: s += "Tree (" + toStringParejas() + ")"; break;
		case DOBLES_PAREJAS: s += "Two pair (" + toStringParejas() + ")"; break;
		case PAREJA: s += "Pair (" + toStringParejas() + ")"; break;
		case CARTA_ALTA: s += "High (" + toStringHigh() + ")"; break;
		default: break;
		}
		
		return s;
	}
	
	public String toStringColor(){
		String s = "";
		ArrayList<Carta> cartasColor = new ArrayList<>();
		switch(color){
		case 'c': cartasColor = cartasColorC; break;
		case 'd': cartasColor = cartasColorD; break;
		case 'h': cartasColor = cartasColorH; break;
		case 's': cartasColor = cartasColorS; break;
		default : break;
		}
		
		for (int i = cartasColor.size() - 1; i >= 0; i--) {
			 s += cartasColor.get(i).toString();
		}
		
		return s;
	}
	
	public String toStringBoF(){
		String s = "";
		for (int i = cartasBoF.size() - 1; i >= 0; i--) {
			 s += cartasBoF.get(i).toString();
		}
		
		return s;
	}
	
	public String toStringParejas(){
		String s = "";
		for (int i = cartasParejas.size() - 1; i >= 0; i--) {
			 s += cartasParejas.get(i).toString();
		}
		
		return s;
	}
	
	public String toStringEscalera(){
		String s = "";
		for (int i = cartasEscalera.size() - 1; i >= 0; i--) {
			 s += cartasEscalera.get(i).toString();
		}
		
		return s;
	}
	
	public String toStringHigh(){
		String s = "";
		s += cartas.get(cartas.size() - 1).toString();
		
		return s;
	}
	
	public String toStringDraws(){
		String s = "";
		
		for (int i = 0; i < draws.size(); i++){
			s += "- Draw: ";
			switch(draws.get(i)){
			case ESCALERA_REAL: s += "Straight flush\n"; break;
			case COLOR: s += "Flush\n"; break;
			case ESCALERA: 
				if (!this.hueco)
					s += "Straight open-ended\n";
				else
					s+= "Straight gutshot\n";
				 break;
			default: break;
			}
		}
		
		return s;
	}

	public ArrayList<Carta> getCartas() {
		return this.cartas;
	}
	public char getProyectoColor() {
		return proyectoColor;
	}

	public void setProyectoColor(char proyectoColor) {
		this.proyectoColor = proyectoColor;
	}

	public char getColor() {
		return color;
	}

	public void setColor(char color) {
		this.color = color;
	}

	public boolean isEscalera() {
		return escalera;
	}

	public void setEscalera(boolean escalera) {
		this.escalera = escalera;
	}
	
	public ArrayList<Carta> getCartasBoF() {
		return cartasBoF;
	}

	public void setCartasBoF(ArrayList<Carta> cartasBoF) {
		this.cartasBoF = cartasBoF;
	}

}
	
		