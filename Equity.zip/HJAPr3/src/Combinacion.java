

public enum Combinacion {
	
	ESCALERA_REAL("straight-flush", 9),
	POKER("four-of-a-", 8),
	FULL("Full-house", 7),
	COLOR("Flush", 6),
	ESCALERA ("Straight", 5),
	TRIO("Tree", 4),
	DOBLES_PAREJAS("Two-pair", 3),
	PAREJA ("Pair", 2),
	CARTA_ALTA("High", 1);
	
	private  String nombreMano;
	private int valor; //Variable para almacenar el valor + alto de una escalera
						// Variable para almacenar el valor de la pareja/trio/trio en un full
	
	/*
	 * Constructora
	 * Parametro nombre con el nombre de la combinacion
	 * Parametro valor con el valor de la combinacion
	 */
	private Combinacion (String nombre, int valor) {
		this.setNombreMano(nombre);
		this.setValor(valor);
	}
	
	public String getNombreMano() {
		return nombreMano;
	}

	private void setNombreMano(String nombreMano) {
		this.nombreMano = nombreMano;
	}
	
	public int getValor() {
		return valor;
	}
	
	public void setValor(int valor) {
		this.valor = valor;
	}
	
	public int compare(Combinacion c1, Combinacion c2) {
		if( c1.equals(null) ) {
			return -1;
		}
		else if (c1.getValor() < c2.getValor())
				return -1;
			
		else if (c1.getValor() > c2.getValor())
			return 1;
		
		else return 0; //Mismo tipo de combinacion
	}
	
	public String toString() {
		String s = "";
		
		s+= this.getNombreMano();
		
		return s;
	}
	
	
	
	
	
}
