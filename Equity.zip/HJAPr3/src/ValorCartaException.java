
@SuppressWarnings("serial")
public class ValorCartaException extends Exception {

	public ValorCartaException(String s) {
		super(s);
	}
}
