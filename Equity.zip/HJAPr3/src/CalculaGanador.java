import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CalculaGanador {

	// Contador partidas ganadas por jugador. Si hay empate de n jugadores se suma
	// 1/n, si no se suma 1
	private float[] contadores;
	// Contador con las equity
	private float[] equity;
	private Turno turno;

	public CalculaGanador() {
		contadores = new float[6];
		equity = new float[6];
	}
	public int calculaEquity(List<Jugador> jugadores, Turno turno, List<Carta> board, List<Carta> cartasSinUsar) {
		contadores = new float[jugadores.size()];
		List<Jugador> jugadoresOut = new ArrayList<>();
		for (Jugador j : jugadores) {
			if (j.getOut()) {
				jugadoresOut.add(j);
			}
		}
		for (Jugador j :jugadoresOut) {
			jugadores.remove(j);
		}
		int nComb = 1;
		this.turno = turno;
		switch (turno) {
		case Preflop:
			permutaPreflop(cartasSinUsar, board, jugadores);// hay que a�adir 5 cartas al aux
			nComb = 658008;
			break;
		case Flop:
			permutaFlop(cartasSinUsar, board, jugadores);// hay que copiar el board al aux y a�adir 2 cartas
			nComb = 666;
			break;
		case Turn:
			permutaTurn(cartasSinUsar, board, jugadores);// hay que copiar el board al aux y a�adir 1 carta
			nComb = 36;
			break;
		case River:
			devuelveGanador(jugadores, board);// hay que ver quien gana
			break;
		default:
			break;
		}
		for (Jugador j : jugadoresOut)
			jugadores.add(j);
		equity = new float[jugadores.size()];
		for (int i = 0; i < jugadores.size(); i++) {
			equity[i] = (contadores[i] * 100) / nComb;
			BigDecimal num = new BigDecimal(equity[i]);
			num = num.setScale(2, RoundingMode.DOWN);
			equity[i] = num.floatValue();
		}

		return -1;
	}

	private void devuelveGanador(List<Jugador> jugadores, List<Carta> board) {
		// En caso de empate se divide 1/numJugadoresEmpate
		// Primero contemplamos el caso de que algun jugador sea NULL (se haya retirado)
		// Luego a�adimos las cartas del board a cada jugador y buscamos combinacion de
		// cada uno
		// Despues vemos que jugador es el que gana:
		// Si es solo uno se suma un punto a su contador
		// Si son varios se suma 1/nGanadores a cada ganador
		////////////////////////////////////////////////////////////////////////

		// Recorro la lista de jugadores buscando los que se han retirado.
		// Si encuentro un retirado lo a�ado a la lista de retirados y lo elimino de la
		// de jugadores.
		// A la vez, si un jugadores no se ha retirado, le a�ado las cartas del board a
		// su mano y buscamos combo.
		for (Jugador j : jugadores) {
			Mano m = j.getManoP1();
			for (int z = 0; z < board.size(); z++) {
				m.addCarta(board.get(z));
			}
			m.combinacionEnMano();
		}

		// Comprobamos cual es el jugador con mejor mano
		JugadorComparator jc = new JugadorComparator();
		Collections.sort(jugadores, jc);
		boolean iguales = true;
		int ind = 0;
		float cont = 1;
		while (iguales && ind < jugadores.size() - 1) {
			if (jc.compare(jugadores.get(ind), jugadores.get(ind + 1)) == 0) {
				cont++;
				ind++;
			} else
				iguales = false;
		}
		// Sumamos puntos (utilizando el atributo de posicion que tiene cada uno)
		for (int h = 0; h < cont; h++) {
			contadores[jugadores.get(h).getPos()] = contadores[jugadores.get(h).getPos()] + 1 / cont;
		}

		// Eliminamos las cartas del board de la mano de cada jugador
		for (Jugador j : jugadores) {
			j.reiniciarMano();
		}

	}

	public float[] getEquity() {
		return equity;
	}

	public void permutaPreflop(List<Carta> cartasSinUsar, List<Carta> board, List<Jugador> jugadores) {
		for (int i = 0; i < cartasSinUsar.size() - 4; i++) {
			for (int j = i + 1; j < cartasSinUsar.size() - 3; j++) {
				for (int z = j + 1; z < cartasSinUsar.size() - 2; z++) {
					for (int x = z + 1; x < cartasSinUsar.size() - 1; x++) {
						for (int w = x + 1; w < cartasSinUsar.size(); w++) {
							// A�ade la combinacion que corresponde al board
							board.add(cartasSinUsar.get(i));
							board.add(cartasSinUsar.get(j));
							board.add(cartasSinUsar.get(z));
							board.add(cartasSinUsar.get(x));
							board.add(cartasSinUsar.get(w));

							// Llama a calcular ganador
							devuelveGanador(jugadores, board);

							// Acaba calcular ganador y borra las cartas del board
							board.remove(cartasSinUsar.get(i));
							board.remove(cartasSinUsar.get(j));
							board.remove(cartasSinUsar.get(z));
							board.remove(cartasSinUsar.get(x));
							board.remove(cartasSinUsar.get(w));

						}
					}
				}
			}
		}
		/*
		 * for (GameObject o : ) o for (B b: bus)
		 * 
		 */
		//
		// equity[i] = contadores[i]*100/658008

	}

	public void permutaFlop(List<Carta> cartasSinUsar, List<Carta> board, List<Jugador> jugadores) {
		for (int i = 0; i < cartasSinUsar.size() - 1; i++) {
			for (int j = i + 1; j < cartasSinUsar.size(); j++) {
				// A�ade la combinacion que corresponde al board
				board.add(cartasSinUsar.get(i));
				board.add(cartasSinUsar.get(j));
				// Llama a calcular ganador
				devuelveGanador(jugadores, board);
				// Acaba calcular ganador y borra las cartas del board
				board.remove(cartasSinUsar.get(i));
				board.remove(cartasSinUsar.get(j));
			}
		}
		//
		// equity[i] = contadores[i]*100/666
	}

	public void permutaTurn(List<Carta> cartasSinUsar, List<Carta> board, List<Jugador> jugadores) {
		for (int i = 0; i < cartasSinUsar.size(); i++) {
			// A�ade la combinacion que corresponde al board
			board.add(cartasSinUsar.get(i));
			// Llama a calcular ganador
			devuelveGanador(jugadores, board);
			// Acaba calcular ganador y borra las cartas del board
			board.remove(cartasSinUsar.get(i));
		}
		//
		// equity[i] = contadores[i]*100/36

	}

}
