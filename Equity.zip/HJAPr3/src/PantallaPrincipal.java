import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Random;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Image;

public class PantallaPrincipal {

	private static JFrame frame;
	private static PanelBoard panelBoard;
	private static PanelJugador panel_2;
	private static PanelJugador panel_1;
	private static PanelJugador panel_3;
	private static PanelJugador panel_4;
	private static PanelJugador panel_5;
	private static PanelJugador panel_6;
	private static Turno turno;
	private static JLabel lblTurno;
	private static List<CartasConPalo> cartas;
	private static List<Carta> cartasSinSalir;
	private static List<Carta> board;
	private static Jugador[] jugadores = new Jugador[6];
	private final int MAX_CARTAS = 52;
	private CalculaGanador calcula;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PantallaPrincipal window = new PantallaPrincipal();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public PantallaPrincipal() {
		cartas = new ArrayList<>();
		cartasSinSalir = new ArrayList<>();
		board = new ArrayList<>();
		calcula = new CalculaGanador();
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 776, 467);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setResizable(false);
		cartas = CartasConPalo.getLista();

		turno = Turno.Preflop;
		for (int i = 0; i < 6; i++) {
			jugadores[i] = new Jugador();
			jugadores[i].setPos(i);
		}

		panel_1 = new PanelJugador();
		panel_1.setBounds(180, 70, 100, 78);
		frame.getContentPane().add(panel_1);

		panel_2 = new PanelJugador();
		panel_2.setBounds(65, 160, 100, 78);
		frame.getContentPane().add(panel_2);

		panel_3 = new PanelJugador();
		panel_3.setBounds(180, 260, 100, 78);
		frame.getContentPane().add(panel_3);

		panel_4 = new PanelJugador();
		panel_4.setBounds(580, 160, 100, 78);
		frame.getContentPane().add(panel_4);

		panel_5 = new PanelJugador();
		panel_5.setBounds(500, 260, 100, 78);
		frame.getContentPane().add(panel_5);

		panel_6 = new PanelJugador();
		panel_6.setBounds(500, 70, 100, 78);

		frame.getContentPane().add(panel_6);

		panelBoard = new PanelBoard();
		panelBoard.setBounds(202, 146, 355, 97);
		frame.getContentPane().add(panelBoard);
		panelBoard.setOpaque(false);

		JPanel panel = new JPanel();
		panel.setOpaque(false);
		panel.setBounds(0, 0, 757, 428);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		JButton botonEquity = new JButton("Calcular Equity");

		JButton btnFold1 = new JButton("Fold");
		btnFold1.setFont(new Font("Tahoma", Font.PLAIN, 9));
		btnFold1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				panel_1.resetEquity();
				panel_2.resetEquity();
				panel_3.resetEquity();
				panel_4.resetEquity();
				panel_5.resetEquity();
				panel_6.resetEquity();
				panel_1.fold();
				jugadores[0].setOut(true);
				botonEquity.setEnabled(true);
				calcula = new CalculaGanador();

			}
		});
		btnFold1.setBounds(207, 53, 53, 16);
		panel.add(btnFold1);
		botonEquity.setEnabled(false);

		JButton btnFold2 = new JButton("Fold");
		btnFold2.setFont(new Font("Tahoma", Font.PLAIN, 9));
		btnFold2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panel_1.resetEquity();
				panel_2.resetEquity();
				panel_3.resetEquity();
				panel_4.resetEquity();
				panel_5.resetEquity();
				panel_6.resetEquity();
				panel_2.fold();
				jugadores[1].setOut(true);
				botonEquity.setEnabled(true);
				calcula = new CalculaGanador();

			}
		});
		btnFold2.setBounds(90, 144, 53, 16);
		panel.add(btnFold2);

		JButton btnFold3 = new JButton("Fold");
		btnFold3.setFont(new Font("Tahoma", Font.PLAIN, 9));
		btnFold3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panel_1.resetEquity();
				panel_2.resetEquity();
				panel_3.resetEquity();
				panel_4.resetEquity();
				panel_5.resetEquity();
				panel_6.resetEquity();
				panel_3.fold();
				jugadores[2].setOut(true);
				botonEquity.setEnabled(true);
				calcula = new CalculaGanador();

			}
		});
		btnFold3.setBounds(207, 243, 53, 16);
		panel.add(btnFold3);

		JButton btnFold6 = new JButton("Fold");
		btnFold6.setFont(new Font("Tahoma", Font.PLAIN, 9));
		btnFold6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panel_1.resetEquity();
				panel_2.resetEquity();
				panel_3.resetEquity();
				panel_4.resetEquity();
				panel_5.resetEquity();
				panel_6.resetEquity();
				panel_6.fold();
				jugadores[5].setOut(true);
				botonEquity.setEnabled(true);
				calcula = new CalculaGanador();

			}
		});
		btnFold6.setBounds(526, 53, 53, 16);
		panel.add(btnFold6);

		JButton btnFold5 = new JButton("Fold");
		btnFold5.setFont(new Font("Tahoma", Font.PLAIN, 9));
		btnFold5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panel_1.resetEquity();
				panel_2.resetEquity();
				panel_3.resetEquity();
				panel_4.resetEquity();
				panel_5.resetEquity();
				panel_6.resetEquity();
				panel_5.fold();
				jugadores[4].setOut(true);
				botonEquity.setEnabled(true);
				calcula = new CalculaGanador();

			}
		});
		btnFold5.setBounds(526, 243, 53, 16);
		panel.add(btnFold5);

		JButton btnFold4 = new JButton("Fold");
		btnFold4.setFont(new Font("Tahoma", Font.PLAIN, 9));
		btnFold4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panel_1.resetEquity();
				panel_2.resetEquity();
				panel_3.resetEquity();
				panel_4.resetEquity();
				panel_5.resetEquity();
				panel_6.resetEquity();
				panel_4.fold();
				jugadores[3].setOut(true);
				botonEquity.setEnabled(true);
				calcula = new CalculaGanador();

			}
		});
		btnFold4.setBounds(605, 144, 53, 16);
		panel.add(btnFold4);

		botonEquity.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int aux = calcularEquity();
				int ind = 0;
				if (!jugadores[0].getOut()) {
					panel_1.setEquity(calcula.getEquity()[jugadores[0].getPos()]);
					ind++;
				}
				if (!jugadores[1].getOut()) {
					panel_2.setEquity(calcula.getEquity()[jugadores[1].getPos()]);
					ind++;
				}
				if (!jugadores[2].getOut()) {
					panel_3.setEquity(calcula.getEquity()[jugadores[2].getPos()]);
					ind++;
				}
				if (!jugadores[3].getOut()) {
					panel_4.setEquity(calcula.getEquity()[jugadores[3].getPos()]);
					ind++;
				}
				if (!jugadores[4].getOut()) {
					panel_5.setEquity(calcula.getEquity()[jugadores[4].getPos()]);
					ind++;
				}
				if (!jugadores[5].getOut()) {
					panel_6.setEquity(calcula.getEquity()[jugadores[5].getPos()]);
					ind++;
				}
				botonEquity.setEnabled(false);

			}
		});
		botonEquity.setBounds(322, 323, 123, 23);
		panel.add(botonEquity);

		JButton btnAsignarTablero = new JButton("Asignar cartas al tablero");
		JButton btnAvanzarTurno = new JButton("Avanzar Turno");
		btnAvanzarTurno.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnAsignarTablero.setEnabled(false);
				if (turno.equals(Turno.River))
					JOptionPane.showMessageDialog(frame, "No se puede avanzar m�s");
				else {
					resetEquity();
					avanzarTurno();
					botonEquity.setEnabled(true);
				}
			}
		});
		btnAvanzarTurno.setEnabled(false);
		btnAvanzarTurno.setBounds(322, 357, 123, 23);
		panel.add(btnAvanzarTurno);
		JButton button = new JButton("Asignar cartas");
		JButton btnAsignarCartas = new JButton("Asignar cartas al azar");
		btnAsignarCartas.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				asignarCartasAzar();
				button.setEnabled(false);
				btnAsignarCartas.setEnabled(false);
				btnAsignarTablero.setEnabled(true);
				botonEquity.setEnabled(true);
				btnAvanzarTurno.setEnabled(true);

			}
		});
		btnAsignarCartas.setBounds(297, 256, 174, 23);
		panel.add(btnAsignarCartas);

		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnAsignarTablero.setEnabled(true);
				PanelSeleccion p = new PanelSeleccion(cartas.size(), cartas, 0);
				button.setEnabled(false);
				btnAsignarCartas.setEnabled(false);
				botonEquity.setEnabled(true);
				btnAvanzarTurno.setEnabled(true);

			}
		});
		button.setBounds(322, 290, 123, 23);
		panel.add(button);

		JButton btnReset = new JButton("Reset");
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				frame.hide();
				main(null);

			}
		});
		btnReset.setBounds(346, 394, 89, 23);
		panel.add(btnReset);

		lblTurno = new JLabel("Turno: " + turno.getNombre());
		lblTurno.setForeground(Color.WHITE);
		lblTurno.setBounds(346, 114, 99, 14);
		panel.add(lblTurno);

		btnAsignarTablero.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (turno.equals(Turno.Preflop)) {
					btnAsignarTablero.setEnabled(false);
					resetEquity();
					PanelSeleccionTablero t = new PanelSeleccionTablero(cartas.size(), cartas, turno);
				} else {
					JOptionPane.showMessageDialog(panelBoard.getParent(), "Solo se pueden asignar cartas con un tablero vac�o");
				}
			}
		});
		btnAsignarTablero.setEnabled(false);
		btnAsignarTablero.setBounds(297, 82, 174, 23);
		panel.add(btnAsignarTablero);

		JLabel lblFondo = new JLabel("New label");
		lblFondo.setBounds(0, 0, 757, 428);
		lblFondo.setIcon(new ImageIcon(PantallaPrincipal.class.getResource("/imgcartas/Board.png")));
		lblFondo.setOpaque(false);

		panel.add(lblFondo);

		PanelJugador p1 = new PanelJugador();

	}

	protected void resetEquity() {
		panel_1.resetEquity();
		panel_2.resetEquity();
		panel_3.resetEquity();
		panel_4.resetEquity();
		panel_5.resetEquity();
		panel_6.resetEquity();
	}

	protected void asignarCartasAzar() {
		for (int i = 0; i < 6; i++) {
			Random r = new Random();
			int posicion1 = (int) (r.nextDouble() * (cartas.size() - 1) + 0);
			CartasConPalo c1 = cartas.get(posicion1);
			cartas.remove(posicion1);
			int posicion2 = (int) (r.nextDouble() * (cartas.size() - 1) + 0);
			CartasConPalo c2 = cartas.get(posicion2);
			cartas.remove(posicion2);
			jugadores[i].setMano(new Carta(c1.getValor(), c1.getPalo()), new Carta(c2.getValor(), c2.getPalo()));

			Collections.sort(jugadores[i].getMano(), new Comparator<Carta>() {
				@Override
				public int compare(Carta o1, Carta o2) {
					return o1.compare(o1, o2);
				}
			});

			if (i == 0) {
				ImageIcon img = new ImageIcon(PantallaPrincipal.class.getResource(c1.getIcono()));
				Icon icono = new ImageIcon(img.getImage().getScaledInstance(panel_1.getCarta1().getWidth(),
						panel_1.getCarta1().getHeight(), Image.SCALE_DEFAULT));
				panel_1.setCarta1(icono);
				img = new ImageIcon(PantallaPrincipal.class.getResource(c2.getIcono()));
				icono = new ImageIcon(img.getImage().getScaledInstance(panel_1.getCarta1().getWidth(),
						panel_1.getCarta1().getHeight(), Image.SCALE_DEFAULT));
				panel_1.setCarta2(icono);
				SwingUtilities.updateComponentTreeUI(frame.getContentPane());
			} else if (i == 1) {
				ImageIcon img = new ImageIcon(PantallaPrincipal.class.getResource(c1.getIcono()));
				Icon icono = new ImageIcon(img.getImage().getScaledInstance(panel_1.getCarta1().getWidth(),
						panel_1.getCarta1().getHeight(), Image.SCALE_DEFAULT));
				panel_2.setCarta1(icono);
				img = new ImageIcon(PantallaPrincipal.class.getResource(c2.getIcono()));
				icono = new ImageIcon(img.getImage().getScaledInstance(panel_1.getCarta1().getWidth(),
						panel_1.getCarta1().getHeight(), Image.SCALE_DEFAULT));
				panel_2.setCarta2(icono);
				SwingUtilities.updateComponentTreeUI(frame.getContentPane());

			} else if (i == 2) {
				ImageIcon img = new ImageIcon(PantallaPrincipal.class.getResource(c1.getIcono()));
				Icon icono = new ImageIcon(img.getImage().getScaledInstance(panel_1.getCarta1().getWidth(),
						panel_1.getCarta1().getHeight(), Image.SCALE_DEFAULT));
				panel_3.setCarta1(icono);
				img = new ImageIcon(PantallaPrincipal.class.getResource(c2.getIcono()));
				icono = new ImageIcon(img.getImage().getScaledInstance(panel_1.getCarta1().getWidth(),
						panel_1.getCarta1().getHeight(), Image.SCALE_DEFAULT));
				panel_3.setCarta2(icono);
				SwingUtilities.updateComponentTreeUI(frame.getContentPane());

			} else if (i == 3) {
				ImageIcon img = new ImageIcon(PantallaPrincipal.class.getResource(c1.getIcono()));
				Icon icono = new ImageIcon(img.getImage().getScaledInstance(panel_1.getCarta1().getWidth(),
						panel_1.getCarta1().getHeight(), Image.SCALE_DEFAULT));
				panel_4.setCarta1(icono);
				img = new ImageIcon(PantallaPrincipal.class.getResource(c2.getIcono()));
				icono = new ImageIcon(img.getImage().getScaledInstance(panel_1.getCarta1().getWidth(),
						panel_1.getCarta1().getHeight(), Image.SCALE_DEFAULT));
				panel_4.setCarta2(icono);
				SwingUtilities.updateComponentTreeUI(frame.getContentPane());

			} else if (i == 4) {
				ImageIcon img = new ImageIcon(PantallaPrincipal.class.getResource(c1.getIcono()));
				Icon icono = new ImageIcon(img.getImage().getScaledInstance(panel_1.getCarta1().getWidth(),
						panel_1.getCarta1().getHeight(), Image.SCALE_DEFAULT));
				panel_5.setCarta1(icono);
				img = new ImageIcon(PantallaPrincipal.class.getResource(c2.getIcono()));
				icono = new ImageIcon(img.getImage().getScaledInstance(panel_1.getCarta1().getWidth(),
						panel_1.getCarta1().getHeight(), Image.SCALE_DEFAULT));
				panel_5.setCarta2(icono);
				SwingUtilities.updateComponentTreeUI(frame.getContentPane());

			} else if (i == 5) {
				ImageIcon img = new ImageIcon(PantallaPrincipal.class.getResource(c1.getIcono()));
				Icon icono = new ImageIcon(img.getImage().getScaledInstance(panel_1.getCarta1().getWidth(),
						panel_1.getCarta1().getHeight(), Image.SCALE_DEFAULT));
				panel_6.setCarta1(icono);
				img = new ImageIcon(PantallaPrincipal.class.getResource(c2.getIcono()));
				icono = new ImageIcon(img.getImage().getScaledInstance(panel_1.getCarta1().getWidth(),
						panel_1.getCarta1().getHeight(), Image.SCALE_DEFAULT));
				panel_6.setCarta2(icono);
				SwingUtilities.updateComponentTreeUI(frame.getContentPane());

			}
		}

	}

	protected int calcularEquity() {
		// TODO Auto-generated method stub
		List<Jugador> listaJug = new ArrayList<>();
		for (int i = 0; i < 6; i++) {
			if (jugadores[i] != null)
				listaJug.add(jugadores[i]);
		}
		setCartasSinSalir2(cartas);
		return calcula.calculaEquity(listaJug, turno, board, cartasSinSalir);

	}

	protected void avanzarTurno() {
		switch (turno) {
		case Preflop: {
			Random r = new Random();
			int posicion1 = (int) (r.nextDouble() * (cartas.size() - 1) + 0);
			CartasConPalo c1 = cartas.get(posicion1);
			cartas.remove(posicion1);
			int posicion2 = (int) (r.nextDouble() * (cartas.size() - 1) + 0);
			CartasConPalo c2 = cartas.get(posicion2);
			cartas.remove(posicion2);
			int posicion3 = (int) (r.nextDouble() * (cartas.size() - 1) + 0);
			CartasConPalo c3 = cartas.get(posicion2);
			cartas.remove(posicion3);

			ImageIcon img = new ImageIcon(PantallaPrincipal.class.getResource(c1.getIcono()));
			Icon icono = new ImageIcon(img.getImage().getScaledInstance(panelBoard.getCarta1().getWidth(),
					panelBoard.getCarta1().getHeight(), Image.SCALE_DEFAULT));
			panelBoard.setCarta(1, icono);
			img = new ImageIcon(PantallaPrincipal.class.getResource(c2.getIcono()));
			icono = new ImageIcon(img.getImage().getScaledInstance(panelBoard.getCarta1().getWidth(),
					panelBoard.getCarta1().getHeight(), Image.SCALE_DEFAULT));
			panelBoard.setCarta(2, icono);
			img = new ImageIcon(PantallaPrincipal.class.getResource(c3.getIcono()));
			icono = new ImageIcon(img.getImage().getScaledInstance(panelBoard.getCarta1().getWidth(),
					panelBoard.getCarta1().getHeight(), Image.SCALE_DEFAULT));
			panelBoard.setCarta(3, icono);
			SwingUtilities.updateComponentTreeUI(frame.getContentPane());
			board.add(new Carta(c1.getValor(), c1.getPalo()));
			board.add(new Carta(c2.getValor(), c2.getPalo()));
			board.add(new Carta(c3.getValor(), c3.getPalo()));

			break;
		}
		case Flop: {
			Random r = new Random();
			int posicion1 = (int) (r.nextDouble() * (cartas.size() - 1) + 0);
			CartasConPalo c1 = cartas.get(posicion1);
			ImageIcon img = new ImageIcon(PantallaPrincipal.class.getResource(c1.getIcono()));
			Icon icono = new ImageIcon(img.getImage().getScaledInstance(panelBoard.getCarta1().getWidth(),
					panelBoard.getCarta1().getHeight(), Image.SCALE_DEFAULT));
			panelBoard.setCarta(4, icono);
			SwingUtilities.updateComponentTreeUI(frame.getContentPane());
			board.add(new Carta(c1.getValor(), c1.getPalo()));
			eliminaCarta(c1);
			break;
		}
		case Turn: {
			Random r = new Random();
			int posicion1 = (int) (r.nextDouble() * (cartas.size() - 1) + 0);
			CartasConPalo c1 = cartas.get(posicion1);
			ImageIcon img = new ImageIcon(PantallaPrincipal.class.getResource(c1.getIcono()));
			Icon icono = new ImageIcon(img.getImage().getScaledInstance(panelBoard.getCarta1().getWidth(),
					panelBoard.getCarta1().getHeight(), Image.SCALE_DEFAULT));
			panelBoard.setCarta(5, icono);
			SwingUtilities.updateComponentTreeUI(frame.getContentPane());
			board.add(new Carta(c1.getValor(), c1.getPalo()));
			eliminaCarta(c1);
			break;
		}
		default:
			break;
		}
		this.turno = Turno.siguiente(turno);
		lblTurno.setText("Turno: " + turno.getNombre());

		// TODO Auto-generated method stub

	}

	public static void setJugador(int i, CartasConPalo c1, CartasConPalo c2) {
		jugadores[i].setMano(new Carta(c1.getValor(), c1.getPalo()), new Carta(c2.getValor(), c2.getPalo()));
		if (i == 0) {
			ImageIcon img = new ImageIcon(PantallaPrincipal.class.getResource(c1.getIcono()));
			Icon icono = new ImageIcon(img.getImage().getScaledInstance(panel_1.getCarta1().getWidth(),
					panel_1.getCarta1().getHeight(), Image.SCALE_DEFAULT));
			panel_1.setCarta1(icono);
			img = new ImageIcon(PantallaPrincipal.class.getResource(c2.getIcono()));
			icono = new ImageIcon(img.getImage().getScaledInstance(panel_1.getCarta1().getWidth(),
					panel_1.getCarta1().getHeight(), Image.SCALE_DEFAULT));
			panel_1.setCarta2(icono);
			SwingUtilities.updateComponentTreeUI(frame.getContentPane());
		} else if (i == 1) {
			ImageIcon img = new ImageIcon(PantallaPrincipal.class.getResource(c1.getIcono()));
			Icon icono = new ImageIcon(img.getImage().getScaledInstance(panel_1.getCarta1().getWidth(),
					panel_1.getCarta1().getHeight(), Image.SCALE_DEFAULT));
			panel_2.setCarta1(icono);
			img = new ImageIcon(PantallaPrincipal.class.getResource(c2.getIcono()));
			icono = new ImageIcon(img.getImage().getScaledInstance(panel_1.getCarta1().getWidth(),
					panel_1.getCarta1().getHeight(), Image.SCALE_DEFAULT));
			panel_2.setCarta2(icono);
			SwingUtilities.updateComponentTreeUI(frame.getContentPane());

		} else if (i == 2) {
			ImageIcon img = new ImageIcon(PantallaPrincipal.class.getResource(c1.getIcono()));
			Icon icono = new ImageIcon(img.getImage().getScaledInstance(panel_1.getCarta1().getWidth(),
					panel_1.getCarta1().getHeight(), Image.SCALE_DEFAULT));
			panel_3.setCarta1(icono);
			img = new ImageIcon(PantallaPrincipal.class.getResource(c2.getIcono()));
			icono = new ImageIcon(img.getImage().getScaledInstance(panel_1.getCarta1().getWidth(),
					panel_1.getCarta1().getHeight(), Image.SCALE_DEFAULT));
			panel_3.setCarta2(icono);
			SwingUtilities.updateComponentTreeUI(frame.getContentPane());

		} else if (i == 3) {
			ImageIcon img = new ImageIcon(PantallaPrincipal.class.getResource(c1.getIcono()));
			Icon icono = new ImageIcon(img.getImage().getScaledInstance(panel_1.getCarta1().getWidth(),
					panel_1.getCarta1().getHeight(), Image.SCALE_DEFAULT));
			panel_4.setCarta1(icono);
			img = new ImageIcon(PantallaPrincipal.class.getResource(c2.getIcono()));
			icono = new ImageIcon(img.getImage().getScaledInstance(panel_1.getCarta1().getWidth(),
					panel_1.getCarta1().getHeight(), Image.SCALE_DEFAULT));
			panel_4.setCarta2(icono);
			SwingUtilities.updateComponentTreeUI(frame.getContentPane());

		} else if (i == 4) {
			ImageIcon img = new ImageIcon(PantallaPrincipal.class.getResource(c1.getIcono()));
			Icon icono = new ImageIcon(img.getImage().getScaledInstance(panel_1.getCarta1().getWidth(),
					panel_1.getCarta1().getHeight(), Image.SCALE_DEFAULT));
			panel_5.setCarta1(icono);
			img = new ImageIcon(PantallaPrincipal.class.getResource(c2.getIcono()));
			icono = new ImageIcon(img.getImage().getScaledInstance(panel_1.getCarta1().getWidth(),
					panel_1.getCarta1().getHeight(), Image.SCALE_DEFAULT));
			panel_5.setCarta2(icono);
			SwingUtilities.updateComponentTreeUI(frame.getContentPane());

		} else if (i == 5) {
			ImageIcon img = new ImageIcon(PantallaPrincipal.class.getResource(c1.getIcono()));
			Icon icono = new ImageIcon(img.getImage().getScaledInstance(panel_1.getCarta1().getWidth(),
					panel_1.getCarta1().getHeight(), Image.SCALE_DEFAULT));
			panel_6.setCarta1(icono);
			img = new ImageIcon(PantallaPrincipal.class.getResource(c2.getIcono()));
			icono = new ImageIcon(img.getImage().getScaledInstance(panel_1.getCarta1().getWidth(),
					panel_1.getCarta1().getHeight(), Image.SCALE_DEFAULT));
			panel_6.setCarta2(icono);
			SwingUtilities.updateComponentTreeUI(frame.getContentPane());

		}
		frame.repaint();
	}

	public static void eliminaCarta(CartasConPalo c) {
		cartas.remove(c);
	}

	public static void setCartasSinSalir(List<Carta> cartas) {
		cartasSinSalir = cartas;
	}

	public static void setCartasSinSalir2(List<CartasConPalo> cartas) {
		// TODO Auto-generated method stub
		cartasSinSalir.clear();
		for (int i = 0; i < cartas.size(); i++) {
			cartasSinSalir.add(cartas.get(i).devuelveCarta());
		}
	}

	public static void setTablero(ArrayList<CartasConPalo> cartasBoard, int numCartas) {
			for (int i = 0; i < numCartas; i++) {
				seteaCartaTablero(cartasBoard.get(i),i+1);
			}
	}

	private static void seteaCartaTablero(CartasConPalo c1, int i) {
		ImageIcon img = new ImageIcon(PantallaPrincipal.class.getResource(c1.getIcono()));
		Icon icono = new ImageIcon(img.getImage().getScaledInstance(panelBoard.getCarta1().getWidth(), panelBoard.getCarta1().getHeight(), Image.SCALE_DEFAULT));
		panelBoard.setCarta(i, icono);
		board.add(new Carta(c1.getValor(), c1.getPalo()));
	}

	public static void eliminaCartas(ArrayList<CartasConPalo> cartasBoard) {
		for (CartasConPalo c : cartasBoard)
			eliminaCarta(c);
	}

	public static void setTurno(Turno flop) {
		turno = flop;
		lblTurno.setText("Turno: " + turno.getNombre());
	}
}
