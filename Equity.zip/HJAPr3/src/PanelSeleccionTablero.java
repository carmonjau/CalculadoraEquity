import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

public class PanelSeleccionTablero extends JFrame {

	private JPanel contentPane;
	private ArrayList<Boolean> eventos = new ArrayList<>();
	private int botonesPulsados;
	private ArrayList<CartasConPalo> cartasBoard = new ArrayList<>();

	/**
	 * Create the frame.
	 * 
	 * @param turno
	 * @param cartas
	 * @param i
	 */
	public PanelSeleccionTablero(int numCartas, List<CartasConPalo> cartas, Turno turno) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.botonesPulsados = 0;
		for (int i = 0; i < cartas.size(); i++) {
			eventos.add(false);
		}
		int filas = numCartas / 4;
		int resto = numCartas % 4;
		if (resto > 0)
			filas++;
		setBounds(100, 100, 269, 795);
		contentPane = new JPanel();
		setContentPane(contentPane);
		contentPane.setLayout(null);
		JPanel panelCartas = new JPanel();
		panelCartas.setBounds(0, 0, 253, 670);
		panelCartas.setLayout(new GridLayout(13, 4, 0, 0));
		int aux = 0;
		for (CartasConPalo c : cartas) {
			BotonCarta carta = new BotonCarta(aux);
			carta.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					if (eventos.get(carta.getPosicion()) == true) {
						eventos.set(carta.getPosicion(), false);
						carta.setBorder(new LineBorder(Color.YELLOW));
						botonesPulsados--;
					} else if (botonesPulsados >= 5 && turno.equals(Turno.Preflop)) {
						JOptionPane.showMessageDialog(panelCartas.getParent(), "El tablero tiene 5 cartas como maximo");
					}

					else {
						eventos.set(carta.getPosicion(), true);
						carta.setBorder(new LineBorder(Color.BLACK));
						botonesPulsados++;
					}
				}
			});
			carta.setSize(50, 50);
			ImageIcon img = new ImageIcon(PantallaPrincipal.class.getResource(c.getIcono()));
			Icon icono = new ImageIcon(
					img.getImage().getScaledInstance(carta.getWidth(), carta.getHeight(), Image.SCALE_DEFAULT));
			carta.setIcon(icono);
			carta.setVisible(true);
			panelCartas.add(carta);
			aux++;
		}
		JButton btnAceptar = new JButton("Aceptar");
		btnAceptar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (numCartas - botonesPulsados >= 35 && numCartas-botonesPulsados < 38) {
					int cont = 0;
					int i = 0;
					while (cont != botonesPulsados) {
						if (eventos.get(i).booleanValue() == true) {
							if (cont != botonesPulsados - 1) {
								cartasBoard.add(cartas.get(i));
								eventos.remove(i);
								cartas.remove(i);
								i--;
							} else {
								cartasBoard.add(cartas.get(i));
								eventos.remove(i);
								cartas.remove(i);
							}
							cont++;

						}
						i++;
					}
					String dialogo = "";
					dialogo += "Has seleccionado las cartas ";
					for (CartasConPalo c : cartasBoard) {
						dialogo += c.getNombre() + " - ";
					}
					dialogo.substring(0, dialogo.length() - 2);
					dialogo += "para el tablero";
					JOptionPane.showMessageDialog(panelCartas.getParent(), dialogo);
					PantallaPrincipal.setTablero(cartasBoard, botonesPulsados);
					PantallaPrincipal.eliminaCartas(cartasBoard);
					switch (botonesPulsados) {
					case 3: PantallaPrincipal.setTurno(Turno.Flop);break;
					case 4: PantallaPrincipal.setTurno(Turno.Turn);break;
					case 5: PantallaPrincipal.setTurno(Turno.River);break;
						default: break;
					}
					// PantallaPrincipal.setCartasSinSalir2(cartas);
					JOptionPane.showMessageDialog(panelCartas.getParent(), "El tablero se ha seleccionado con exito");
					hide();

				} else if (numCartas - botonesPulsados < 35)
					JOptionPane.showMessageDialog(panelCartas.getParent(), "El tablero tiene 5 cartas como maximo");
				else
					JOptionPane.showMessageDialog(panelCartas.getParent(), "El tablero tiene 3 cartas como minimo");


			}
		});
		btnAceptar.setBounds(10, 681, 217, 23);
		panelCartas.setVisible(true);
		contentPane.add(panelCartas);
		contentPane.add(btnAceptar);
		contentPane.setVisible(true);
		setLocation(900, 0);
		this.setVisible(true);
	}

}
