
/**
 * 
 * panel muestre cartas seleccionadas al aceptar jugador
 * comprobar haya dos seleccionadas
 */
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

import java.awt.GridLayout;
import java.awt.Image;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class PanelSeleccion extends JFrame {

	private JPanel contentPane;
	private ArrayList<Boolean> eventos = new ArrayList<>();
	private int botonesPulsados = 0;
	private CartasConPalo carta1;
	private CartasConPalo carta2;
	private int jugador;

	PanelSeleccion(int numCartas, List<CartasConPalo> cartas, int j) {

		jugador = j;
		setTitle("Jugador " + (jugador + 1));
		for (int i = 0; i < cartas.size(); i++) {
			eventos.add(false);
		}
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		int filas = numCartas / 4;
		int resto = numCartas % 4;
		if (resto > 0)
			filas++;
		setBounds(100, 100, 269, 795);
		contentPane = new JPanel();
		setContentPane(contentPane);
		contentPane.setLayout(null);
		JPanel panelCartas = new JPanel();
		panelCartas.setBounds(0, 0, 253, 670);
		panelCartas.setLayout(new GridLayout(13, 4, 0, 0));
		int aux = 0;
		for (CartasConPalo c : cartas) {
			BotonCarta carta = new BotonCarta(aux);
			carta.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					if (eventos.get(carta.getPosicion()) == true) {
						eventos.set(carta.getPosicion(), false);
						carta.setBorder(new LineBorder(Color.YELLOW));
						botonesPulsados--;
					} else if (botonesPulsados >= 2) {
						JOptionPane.showMessageDialog(panelCartas.getParent(),
								"Cada jugador tiene 2 cartas como maximo");
					} else {
						eventos.set(carta.getPosicion(), true);
						carta.setBorder(new LineBorder(Color.BLACK));

						botonesPulsados++;
					}
				}
			});
			carta.setSize(50, 50);
			ImageIcon img = new ImageIcon(PantallaPrincipal.class.getResource(c.getIcono()));
			Icon icono = new ImageIcon(
					img.getImage().getScaledInstance(carta.getWidth(), carta.getHeight(), Image.SCALE_DEFAULT));
			carta.setIcon(icono);
			carta.setVisible(true);
			panelCartas.add(carta);
			aux++;
		}
		JButton btnAceptar = new JButton("Aceptar");
		btnAceptar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (botonesPulsados == 2) {
					int cont = 0;
					int i = 0;
					while (cont != 2) {
						if (eventos.get(i).booleanValue() == true) {
							if (cont == 0) {
								carta1 = cartas.get(i);
								eventos.remove(i);
								cartas.remove(i);
								i--;
							} else if (cont == 1) {
								carta2 = cartas.get(i);
								eventos.remove(i);
								cartas.remove(i);
							}
							cont++;

						}
						i++;
					}
					JOptionPane.showMessageDialog(panelCartas.getParent(),
							"Has seleccionado las cartas " + carta1.getValor() + carta1.getPalo() + " - "
									+ carta2.getValor() + carta2.getPalo() +  " para el jugador " + (jugador + 1));
					PantallaPrincipal.setJugador(jugador, carta1, carta2);
					List<Carta> carta = new ArrayList<>();
					for (CartasConPalo c : cartas) {
						carta.add(new Carta(c.getValor(), c.getPalo()));
					}
					

					// Comprobar botonesPulsados == 2
					// Quitar cartas de cartasSinSalir
					// Setea jugador
					// En pantallaPrincipal mete bucle para los 6

					jugador = jugador + 1;
					PantallaPrincipal.eliminaCarta(carta1);
					PantallaPrincipal.eliminaCarta(carta2);
					if (jugador < 6) {
						hide();
						new PanelSeleccion(numCartas, cartas, jugador);
					} else {
					//	PantallaPrincipal.setCartasSinSalir2(cartas);
						JOptionPane.showMessageDialog(panelCartas.getParent(), "Los 6 jugadores han sido creados");
						hide();

					}

				}else JOptionPane.showMessageDialog(panelCartas.getParent(), "Se deben seleccionar 2 cartas ");

					
			}
		});
		btnAceptar.setBounds(10, 681, 217, 23);
		panelCartas.setVisible(true);
		contentPane.add(panelCartas);
		contentPane.add(btnAceptar);
		contentPane.setVisible(true);
		setLocation(900, 0);
		this.setVisible(true);
	}
}
