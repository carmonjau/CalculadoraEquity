import javax.swing.JPanel;

import javax.swing.Icon;
import javax.swing.JLabel;

public class PanelBoard extends JPanel {

	private JLabel carta1;
	private JLabel carta2;
	private JLabel carta3;
	private JLabel carta4;
	private JLabel carta5;
	
	public PanelBoard() {
		setLayout(null);
		
		carta1 = new JLabel();
		setBounds(202, 146, 355, 97);
		carta1.setBounds(0, 0, 71, 97);
		add(carta1);
		
		carta2 = new JLabel();
		carta2.setBounds(71, 0, 71, 97);
		add(carta2);
		
		carta3 = new JLabel();
		carta3.setBounds(142, 0, 71, 97);
		add(carta3);
		
		carta4 = new JLabel();
		carta4.setBounds(213, 0, 71, 97);
		add(carta4);
		
		carta5 = new JLabel();
		carta5.setBounds(284, 0, 71, 97);
		add(carta5);

	}
	public void setCarta(Integer i,Icon icono) {
		switch(i) {
		case 1: carta1.setIcon(icono); carta1.setVisible(true);	carta1.repaint(); break;
		case 2: carta2.setIcon(icono); carta2.setVisible(true);	carta2.repaint();break;
		case 3: carta3.setIcon(icono); carta3.setVisible(true);	carta3.repaint();break;
		case 4: carta4.setIcon(icono); carta4.setVisible(true);	carta4.repaint();break;
		case 5: carta5.setIcon(icono); carta5.setVisible(true);	carta5.repaint(); break;
		default: break;
		}
	}
	
	public JLabel getCarta1() {
		return carta1;
	}
	public void reset() {
		carta1 = new JLabel();
		setBounds(202, 146, 355, 97);
		carta1.setBounds(0, 0, 71, 97);

		
		carta2 = new JLabel();
		carta2.setBounds(71, 0, 71, 97);

		
		carta3 = new JLabel();
		carta3.setBounds(142, 0, 71, 97);

		
		carta4 = new JLabel();
		carta4.setBounds(213, 0, 71, 97);

		
		carta5 = new JLabel();
		carta5.setBounds(284, 0, 71, 97);

		// TODO Auto-generated method stub
		
	}
	

}
