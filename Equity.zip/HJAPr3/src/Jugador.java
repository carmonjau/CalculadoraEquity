import java.util.ArrayList;
import java.util.List;

public class Jugador {

	private Carta carta1;
	private Carta carta2;
	private Mano mano;
	private int pos;
	private boolean out;
	
	public Jugador() {
		carta1 = new Carta();
		carta2 = new Carta();
		mano = new Mano();
		pos = -1;
		out = false;
	}
	
	public void reiniciarMano(){
		mano = new Mano();
		mano.addCarta(carta1);
		mano.addCarta(carta2);
	}
	
	public void setMano(Carta c1, Carta c2) {
		carta1 = c1;
		mano.addCarta(c1);
		carta2 = c2;
		mano.addCarta(c2);
	}
	
	public void setOut(boolean b){
		out = b;
	}
	
	public boolean getOut(){
		return out;
	}
	
	public void setPos(int x){
		pos = x;
	}
	
	public int getPos(){
		return pos;
	}
	
	public List<Carta> getMano(){
		List<Carta> retorno = new ArrayList<>();
		
		retorno.add(carta1);
		retorno.add(carta2);
		
		return retorno;
	}
	
	public void addCartaMano(Carta c){
		mano.addCarta(c);
	}
	
	public Mano getManoP1(){
		return mano;
	}

}
