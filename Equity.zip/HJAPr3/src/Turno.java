
public enum Turno { Preflop("Pre-flop"), Flop("Flop"), Turn("Turn"), River("River");
	
	private String nombre;
	
	private Turno (String n) {
		this.nombre = n;
	}

	public String getNombre() {
		return nombre;
	}

	public static Turno siguiente(Turno turno) {
		Turno t = null;
		switch (turno) {
		case Preflop: t = Turno.Flop; break;
		case Flop: t = Turno.Turn; break;
		case Turn: t = Turno.River; break;
		}
		return t;
	}
}
