
import java.util.Comparator;

public class JugadorComparator implements Comparator<Jugador> {

	@Override
	public int compare(Jugador m1, Jugador m2) {
		
		/*
		 * 
		 */
		
		boolean iguales = true;
		int retorno = 0;
		switch(m1.getManoP1().getCombinacion().compare(m1.getManoP1().getCombinacion(), m2.getManoP1().getCombinacion())) {
		case 1:
			retorno = -1;//La mano m1 es mejor que la mano m2
			break;
		case 0:
			//La combinacion de la mano m1 es igual que la m2, comprobar la carta de la combinacion
			int i = 0;
			while (iguales && i <= 4) {
				if (m1.getManoP1().getCombinacion().equals(Combinacion.ESCALERA_REAL)) {
					retorno = m1.getManoP1().getCartasBoF().get(i).compare(m1.getManoP1().getCartasBoF().get(i), m2.getManoP1().getCartasBoF().get(i));
					if (retorno != 0)
						iguales = false;
					else
						i++;
				}
				else if(m1.getManoP1().getCombinacion().equals(Combinacion.POKER)) {
					retorno = m1.getManoP1().getCartasBoF().get(i).compare(m1.getManoP1().getCartasBoF().get(i), m2.getManoP1().getCartasBoF().get(i));
					if (retorno != 0)
						iguales = false;
					else if (i == 0)
						i = 4;
					else
						i++;
				}
				else if (m1.getManoP1().getCombinacion().equals(Combinacion.FULL)) {
					retorno = m1.getManoP1().getCartasBoF().get(i).compare(m1.getManoP1().getCartasBoF().get(i), m2.getManoP1().getCartasBoF().get(i));
					if (retorno != 0)
						iguales = false;
					else if (i == 0)
						i = 3;
					else
						i = 5;
				}
				else if (m1.getManoP1().getCombinacion().equals(Combinacion.COLOR)) {
						retorno = m1.getManoP1().getCartasBoF().get(i).compare(m1.getManoP1().getCartasBoF().get(m1.getManoP1().getCartasBoF().size()-(i+1)), m2.getManoP1().getCartasBoF().get(m2.getManoP1().getCartasBoF().size()-(i+1)));
						if (retorno != 0)
							iguales = false;
						else
							i++;
				}
				else if (m1.getManoP1().getCombinacion().equals(Combinacion.ESCALERA)) {
					retorno = m1.getManoP1().getCartasBoF().get(i).compare(m1.getManoP1().getCartasBoF().get(m1.getManoP1().getCartasBoF().size()-(i+1)), m2.getManoP1().getCartasBoF().get(m2.getManoP1().getCartasBoF().size()-(i+1)));
					if (retorno != 0)
						iguales = false;
					else
						i++;
				}
				
				
				else if (m1.getManoP1().getCombinacion().equals(Combinacion.TRIO)) {
					retorno = m1.getManoP1().getCartasBoF().get(i).compare(m1.getManoP1().getCartasBoF().get(i), m2.getManoP1().getCartasBoF().get(i));
					if (retorno != 0)
						iguales = false;
					else if (i == 0){
						i = 3;
					}
					else
						i++;
						
				}
				else if(m1.getManoP1().getCombinacion().equals(Combinacion.DOBLES_PAREJAS)) {
					retorno = m1.getManoP1().getCartasBoF().get(i).compare(m1.getManoP1().getCartasBoF().get(i), m2.getManoP1().getCartasBoF().get(i));
					if (retorno != 0)
						iguales = false;
					else if (i == 0)
						i = 2;
					else if (i == 2)
						i = 4;
					else
						i++;
				}
				else if (m1.getManoP1().getCombinacion().equals(Combinacion.PAREJA)) {
					retorno = m1.getManoP1().getCartasBoF().get(i).compare(m1.getManoP1().getCartasBoF().get(i), m2.getManoP1().getCartasBoF().get(i));
					if (retorno != 0)
						iguales = false;
					else if (i == 0)
						i = 2;
					else
						i++;
				}
				else {
					retorno = m1.getManoP1().getCartasBoF().get(i).compare(m1.getManoP1().getCartasBoF().get(i), m2.getManoP1().getCartasBoF().get(i));
					if (retorno != 0)
						iguales = false;
					else
						i++;
				}
			}
			if (iguales)
				retorno = 0;
			if (retorno == 1)
				retorno = -1;
			else if (retorno == -1)
				retorno = 1;
			break;
		case -1:
			retorno = 1; 
			break;
			//La mano m2 es mejor que la mano m1
		}
		return retorno;
	}

}