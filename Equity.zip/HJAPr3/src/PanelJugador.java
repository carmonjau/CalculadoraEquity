import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.Icon;
import javax.swing.JLabel;
import java.awt.Color;

public class PanelJugador extends JPanel {

	private JLabel carta1;
	private JLabel carta2;
	private JLabel equity;

	/**
	 * Create the panel.
	 */
	
	public PanelJugador() {
		setLayout(null);
		this.setBounds(0,0,100,78);
		setOpaque(false);
		
		equity = new JLabel("");
		equity.setForeground(Color.WHITE);
		equity.setBounds(0, 50, 100, 28);
		add(equity);
		
		carta1 = new JLabel("");
		carta1.setBounds(0, 0, 50, 50);
		add(carta1);
		
		carta2 = new JLabel("");
		carta2.setBounds(50, 0, 50, 50);
		add(carta2);
	}
	
	
	public void setEquity(float e) {
		
		equity.setVerticalAlignment(SwingConstants.CENTER);
		equity.setHorizontalAlignment(SwingConstants.CENTER);
		equity.setText(Float.toString(e)+"%");
	}
	
	public void setCarta1(Icon i) {
		carta1.setIcon(i);
		carta1.setVisible(true);
		carta1.repaint();
	}
	
	public void setCarta2(Icon i) {
		carta2.setIcon(i);
		carta2.setVisible(true);
		carta2.repaint();
	
	}
	public void resetEquity() {
		equity.setText("");
	}

	public void fold() {
		equity.setText("");
		carta1.setIcon(null);
		carta2.setIcon(null);
	}


	public JLabel getCarta1() {
		// TODO Auto-generated method stub
		return carta1;
	}


	public void reset() {
		
		equity = new JLabel("");
		equity.setForeground(Color.WHITE);
		equity.setBounds(0, 50, 100, 28);
		
		carta1 = new JLabel("");
		carta1.setBounds(0, 0, 50, 50);
		
		carta2 = new JLabel("");
		carta2.setBounds(50, 0, 50, 50);
	}

}
