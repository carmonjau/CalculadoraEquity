import java.util.ArrayList;
import java.util.List;

import javax.swing.ImageIcon;


public enum CartasConPalo {
	AS_CORAZON("Ah", new ImageIcon(("/imgcartas/ace_of_hearts.png"))),
	AS_ESPADA("As",new ImageIcon(("/imgcartas/ace_of_spades.png"))),
	AS_DIAMANTE("Ad",new ImageIcon(("/imgcartas/ace_of_diamonds.png"))),
	AS_TREBOL("Ac",new ImageIcon(("/imgcartas/ace_of_clubs.png"))),
	K_CORAZON("Kh",new ImageIcon(("/imgcartas/king_of_hearts2.png"))),
	K_ESPADA("Ks",new ImageIcon(("/imgcartas/king_of_spades2.png"))),
	K_DIAMANTE("Kd",new ImageIcon(("/imgcartas/king_of_diamonds2.png"))),
	K_TREBOL("Kc",new ImageIcon(("/imgcartas/king_of_clubs2.png"))),
	Q_CORAZON("Qh",new ImageIcon(("/imgcartas/queen_of_hearts2.png"))),
	Q_ESPADA("Qs",new ImageIcon(("/imgcartas/queen_of_spades2.png"))),
	Q_DIAMANTE("Qd",new ImageIcon(("/imgcartas/queen_of_diamonds2.png"))),
	Q_TREBOL("Qc",new ImageIcon(("/imgcartas/queen_of_clubs2.png"))),
	J_CORAZON("Jh",new ImageIcon(("/imgcartas/jack_of_hearts2.png"))),
	J_ESPADA("Js",new ImageIcon(("/imgcartas/jack_of_spades2.png"))),
	J_DIAMANTE("Jd",new ImageIcon(("/imgcartas/jack_of_diamonds2.png"))),
	J_TREBOL("Jc",new ImageIcon(("/imgcartas/jack_of_clubs2.png"))),
	T_CORAZON("Th",new ImageIcon(("/imgcartas/10_of_hearts.png"))),
	T_ESPADA("Ts",new ImageIcon(("/imgcartas/10_of_spades.png"))),
	T_DIAMANTE("Td",new ImageIcon(("/imgcartas/10_of_diamonds.png"))),
	T_TREBOL("Tc",new ImageIcon(("/imgcartas/10_of_clubs.png"))),
	NUEVE_CORAZON("9h",new ImageIcon(("/imgcartas/9_of_hearts.png"))),
	NUEVE_ESPADA("9s",new ImageIcon(("/imgcartas/9_of_spades.png"))),
	NUEVE_DIAMANTE("9d",new ImageIcon(("/imgcartas/9_of_diamonds.png"))),
	NUEVE_TREBOL("9c",new ImageIcon(("/imgcartas/9_of_clubs.png"))),
	OCHO_CORAZON("8h",new ImageIcon(("/imgcartas/8_of_hearts.png"))),
	OCHO_ESPADA("8s",new ImageIcon(("/imgcartas/8_of_spades.png"))),
	OCHO_DIAMANTE("8d",new ImageIcon(("/imgcartas/8_of_diamonds.png"))),
	OCHO_TREBOL("8c",new ImageIcon(("/imgcartas/8_of_clubs.png"))),
	SIETE_CORAZON("7h",new ImageIcon(("/imgcartas/7_of_hearts.png"))),
	SIETE_ESPADA("7s", new ImageIcon(("/imgcartas/7_of_spades.png"))),
	SIETE_DIAMANTE("7d",new ImageIcon(("/imgcartas/7_of_diamonds.png"))),
	SIETE_TREBOL("7c",new ImageIcon(("/imgcartas/7_of_clubs.png"))),
	SEIS_CORAZON("6h",new ImageIcon(("/imgcartas/6_of_hearts.png"))),
	SEIS_ESPADA("6s",new ImageIcon(("/imgcartas/6_of_spades.png"))),
	SEIS_DIAMANTE("6d",new ImageIcon(("/imgcartas/6_of_diamonds.png"))),
	SEIS_TREBOL("6c",new ImageIcon(("/imgcartas/6_of_clubs.png"))),
	CINCO_CORAZON("5h",new ImageIcon(("/imgcartas/5_of_hearts.png"))),
	CINCO_ESPADA("5s",new ImageIcon(("/imgcartas/5_of_spades.png"))),
	CINCO_DIAMANTE("5d",new ImageIcon(("/imgcartas/5_of_diamonds.png"))),
	CINCO_TREBOL("5c",new ImageIcon(("/imgcartas/5_of_clubs.png"))),
	CUATRO_CORAZON("4h",new ImageIcon(("/imgcartas/4_of_hearts.png"))),
	CUATRO_ESPADA("4s",new ImageIcon(("/imgcartas/4_of_spades.png"))),
	CUATRO_DIAMANTE("4d",new ImageIcon(("/imgcartas/4_of_diamonds.png"))),
	CUATRO_TREBOL("4c",new ImageIcon(("/imgcartas/4_of_clubs.png"))),
	TRES_CORAZON("3h",new ImageIcon(("/imgcartas/3_of_hearts.png"))),
	TRES_ESPADA("3s",new ImageIcon(("/imgcartas/3_of_spades.png"))),
	TRES_DIAMANTE("3d",new ImageIcon(("/imgcartas/3_of_diamonds.png"))),
	TRES_TREBOL("3c",new ImageIcon(("/imgcartas/3_of_clubs.png"))),
	DOS_CORAZON("2h",new ImageIcon(("/imgcartas/2_of_hearts.png"))),
	DOS_ESPADA("2s",new ImageIcon(("/imgcartas/2_of_spades.png"))),
	DOS_DIAMANTE("2d",new ImageIcon(("/imgcartas/2_of_diamonds.png"))),
	DOS_TREBOL("2c",new ImageIcon(("/imgcartas/2_of_clubs.png")));

	private String nombre;
	private ImageIcon icono;
	private CartasConPalo(String nombre, ImageIcon icono) {
	        this.nombre = nombre;
	        this.icono = icono;
	    }
	
	public String getNombre() {
		return this.nombre;
	}
	
	public String getIcono() {
		return this.icono.getDescription();
	}
	
	public char getPalo() {
		return nombre.charAt(1);
	}
	
	public char getValor() {
		return nombre.charAt(0);
	}

	public static CartasConPalo devuelveEnum(Carta c) {
		
		String s = "";
		s+= c.getValor();
		s+= c.getPalo();
		for (CartasConPalo c1 : CartasConPalo.values()) {
			if (c1.getNombre().toLowerCase().equals(s.toLowerCase()))
				return c1;
		}
		return null;
	}

	public static List<CartasConPalo> getLista() {
		List<CartasConPalo> retorno = new ArrayList<>();
		for (CartasConPalo c : CartasConPalo.values())
			retorno.add(c);
		return retorno;
	}
	
	public Carta devuelveCarta() {
		
		Carta c = new Carta(this.getValor(), this.getPalo());
		
		return c;
	}
	
	
	
	
	
}
