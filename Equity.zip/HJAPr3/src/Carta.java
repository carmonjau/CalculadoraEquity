public class Carta extends Object{

	private char valor;
	private char palo;
	private int hashCode;
	
	public Carta() {
		
	}
	
	public Carta(char valor, char palo) {
		this.valor = valor;
		this.palo = palo;
		hashCode = hashCode();
	}
	public void parseaValorCarta(String valor) throws ValorCartaException {
		
		valor = valor.toUpperCase();
		switch (valor) {
			case "A": this.setValor('A'); break;
			case "K": this.setValor('K'); break;
			case "Q": this.setValor('Q'); break;
			case "J": this.setValor('T'); break;
			case "T": this.setValor('J'); break;
			case "9": this.setValor('9'); break;
			case "8": this.setValor('8'); break;
			case "7": this.setValor('7'); break;
			case "6": this.setValor('6'); break;
			case "5": this.setValor('5'); break;
			case "4": this.setValor('4'); break;
			case "3": this.setValor('3'); break;
			case "2": this.setValor('2'); break;
			default: throw new ValorCartaException("Valor no existente");
		}
	}
	
	public void parseaPaloCarta(String palo) throws PaloCartaException {
		
		palo = palo.toUpperCase();
		switch (palo) {
			case "H": this.setPalo('h'); break;
			case "D": this.setPalo('d'); break;
			case "C": this.setPalo('c'); break;
			case "S": this.setPalo('s'); break;
			default: throw new PaloCartaException("Palo no existente");
		}
	}
	
	public char parseaAsAUno(char valor) {
		return '1';
	}
	
	public char getValor() {
		return valor;
	}
	
	public int getValorP1() {
		return valorCharToInt(valor);
	}


	public void setValor(char valor) {
		this.valor = valor;
	}


	public char getPalo() {
		return palo;
	}


	public void setPalo(char palo) {
		this.palo = palo;
	}
	
	public void setHashCode(){
		hashCode = hashCode();
	}
	
	public int getHashCode(){
		return hashCode;
	}
	
	public int hashCode() {
		int extra = 0;
		switch (palo) {
		case 'c': extra++; break;
		case 'd': extra+=2; break;
		case 'h': extra+=3; break;
		case 's': extra+=4; break;
		default: break;

		}
		return valorCharToInt(valor)*10 + extra;
	}
	
	private int valorCharToInt(char valor){
		int c = 0;
		switch (valor) {
			case 'A': c = 14; break;
			case 'K': c = 13; break;
			case 'Q': c = 12; break;
			case 'J': c = 11; break;
			case 'T': c = 10; break;
			case '9': c = 9; break;
			case '8': c = 8; break;
			case '7': c = 7; break;
			case '6': c = 6; break;
			case '5': c = 5; break;
			case '4': c = 4; break;
			case '3': c = 3; break;
			case '2': c = 2; break;
			default: break;
		}
		return c;
	}
	
	
	public String toString(){
		String s = "";
		switch (valor) {
			case 'A': s = "A"; break;
			case 'K': s = "K"; break;
			case 'Q': s = "Q"; break;
			case 'J': s = "J"; break;
			case 'T': s = "T"; break;
			case '9': s = "9"; break;
			case '8': s = "8"; break;
			case '7': s = "7"; break;
			case '6': s = "6"; break;
			case '5': s = "5"; break;
			case '4': s = "4"; break;
			case '3': s = "3"; break;
			case '2': s = "2"; break;
			case '1': s = "A"; break;
			default: break;
		}
		s += palo;
		return s;
	}
	
	/**
	 * 
	 * @param valor de la carta, comenzando por el 1 para el 2 y ascendiendo
	 * @return String con el valor de la carta 
	 * @throws ValorCartaException
	 */
	public String parseaValorCarta(int valor) {
		
		switch (valor) {
			case 13: return "A"; 
			case 12: return "K";
			case 11: return "Q";
			case 10: return "J";
			case 9:  return "T";
			case 8:  return "9";
			case 7:  return "8";
			case 6:  return "7";
			case 5:  return "6";
			case 4:  return "5";
			case 3:  return "4";
			case 2:  return "3";
			case 1: return "2";
			default: break;
		}
		return "";
	}
	
	public int devuelveValorCarta() {
		int s = -1;
		switch (valor) {
		case 'A': s = 14; break;
		case 'K': s = 13; break;
		case 'Q': s = 12; break;
		case 'J': s = 11; break;
		case 'T': s = 10; break;
		case '9': s = 9; break;
		case '8': s = 8; break;
		case '7': s = 7; break;
		case '6': s = 6; break;
		case '5': s = 5; break;
		case '4': s = 4; break;
		case '3': s = 3; break;
		case '2': s = 2; break;
		case '1': s = 14; break;
		default: break;
		}
		return s;
	}
	
	public int compare(Carta c1, Carta c2) {
		if (c1.devuelveValorCarta() > c2.devuelveValorCarta())
			return 1;
		else if (c1.devuelveValorCarta() < c2.devuelveValorCarta())
			return -1;
		else
			return 0;
	}
}