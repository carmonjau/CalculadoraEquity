
@SuppressWarnings("serial")
public class PaloCartaException extends Exception {

	public PaloCartaException(String string) {
		super(string);
	}

}
