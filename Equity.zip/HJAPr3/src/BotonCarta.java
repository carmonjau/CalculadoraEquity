import java.awt.Color;

import javax.swing.JButton;
import javax.swing.JToggleButton;
import javax.swing.border.LineBorder;

@SuppressWarnings("serial")
public class BotonCarta extends JToggleButton {
	private int posicion;
	
	public BotonCarta(int pos) {
		super();
		this.setBorder(new LineBorder(Color.YELLOW));
		this.posicion = pos;
	}
	
	public int getPosicion() {
		return posicion;
	}

}
